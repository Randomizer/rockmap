# RockMap 🎸🗺️

En interaktiv karta som visar var stora band spelar konserter.

## Funktioner
- Visa konserter på Mapbox-karta
- Filtrera per månad och land (dynamiskt genererade filter)
- Popup med information och biljettlänk

## Så använder du
1. Öppna `index.html` i webbläsare – allt fungerar lokalt.
2. Eller ladda upp till ett GitHub-repo och aktivera GitHub Pages.

Byggd med HTML + JavaScript + Mapbox GL JS.

